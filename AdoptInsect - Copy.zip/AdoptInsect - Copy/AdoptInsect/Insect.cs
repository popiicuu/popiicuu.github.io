﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptInsect
{
    internal class Insect
    {

        public Insect()
        {
        }
        public string Name { get; set; }

        public Insect(string name)
        {
            Name = name;
        }

        public void Eat(string food)
        {
            Console.WriteLine($"{Name} is eating {food}.");
        }

        public void PlaceInEnvironment(string environment)
        {
            Console.WriteLine($"You place {Name} gently in the {environment}.");
            switch (environment.ToLower())
            {
                case "Garden Green House":
                    Console.WriteLine($"The Garden Green House provides a wide space for {Name} but the next few days you realize that {Name} is gone forever. Probably dead too.  .");
                    break;
                case "Abandon it in the forest":
                    Console.WriteLine($"You decided that like every other animal of nature, {Name} must be set free to live in the wild." +
                        $"You walk into the woods and let {Name} free but as you set him on a stick, a bird comes in quick to eat him and fly away. You have killed {Name}.");
                    break;
                case "Tiny Plastic bug container":
                    Console.WriteLine($"You purchase one of those mini plastic and colorful lid containers for {Name}'s home. Yet without the proper ventilation, greenery, and space, {Name} decides enough is enough and dies.");
                    break;
                case "Terrarium":
                    Console.WriteLine($"You let {Name} live in a home grown fish tank terrarium. The terrarium is filled with lushious plants, logs, and composted dirst. You set {Name} down inside the terraium and leave them to explore and make themselves at home.  ");
                    break;
                case "Under your Skin":
                    Console.WriteLine($"You decide that love {Name} so much that you can't bare being seperated from them. You in an act of despiration, you shove {Name} into your ear and wait until you can hear them crawling around." +
                        $"You celebrate in joy for a few days but eventually {Name} gets hungry and starts to eat at your brain, muscle, and organs. You die as {Name} eats the rest of you from the inside out. ");
                    break;
                default:
                    Console.WriteLine($"You put {Name} in the chosen location.");
                    break;
            }
        }
    }
}
//Coded it and worked out with ChatGPT AI assitance