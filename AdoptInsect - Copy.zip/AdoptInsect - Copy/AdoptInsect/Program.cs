﻿// See https://aka.ms/new-console-template for more information

using AdoptInsect;

namespace adoptinsectgame
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Adopt an Insect! What is your name?");
            Console.ReadLine();
            Console.Write("Enter your name: ");
            string playerName = Console.ReadLine();
            Player player = new Player(playerName);

            Console.Write($"{playerName}, What kind of insect would you love to adopt?");

            List<string> availableInsects = new List<string> { "Butterfly", "Bee", "Ant", "Dragonfly", "Ladybug" };

            // Display available insects for the player to choose from
            Console.WriteLine("Available insects to adopt:");
            for (int i = 0; i < availableInsects.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {availableInsects[i]}");
            }
            // Prompt the player to choose an insect
            Console.Write($"Hello, {playerName}! Please enter the number of the insect you'd like to adopt: ");
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > availableInsects.Count)
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
            }


            // Prompt the player to adopt an insect
            Console.Write($"Please enter the name of the insect you'd like to adopt {playerName}: ");
            string insectName = Console.ReadLine();
            player.AdoptInsect(insectName);

            Console.WriteLine($"Now that you have adopted {insectName}, Will you feed him?");
            Console.Write("");


            // Feed the insect
            Console.Write($"What would you like to feed {player.AdoptedInsect.Name}? ");
            string food = Console.ReadLine();
            player.FeedInsect(food);

            // List of available environments
            List<string> availableEnvironments = new List<string> { "Garden Green House", "Abandon it in the forest", "Tiny plastic bug container", "Terrarium", "Under your skin." };

            // Display available environments for the player to choose from
            Console.WriteLine("Here is our wide and fun selection of locations to let your insect live in:");
            for (int i = 0; i < availableEnvironments.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {availableEnvironments[i]}");
            }

            // Prompt the player to choose an environment
            Console.Write($"Where would you like {player.AdoptedInsect.Name} to live in? Enter the number.");
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > availableEnvironments.Count)
            {
                Console.WriteLine("Invalid input. Please enter a damn number.");
            }

            string chosenEnvironment = availableEnvironments[choice - 1];

            // Place the insect in the chosen environment
            player.PlaceInsectInEnvironment(chosenEnvironment);
        }
    }
   //Coded it and worked out with ChatGPT AI assitance
//
}

