﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptInsect
{
    internal class Player
    {

        public string Name { get; set; }
        public Insect AdoptedInsect { get; set; }

        public Player(string name)
        {
            Name = name;
        }

        public void AdoptInsect(string insectName)
        {
            AdoptedInsect = new Insect(insectName);
            Console.WriteLine($"{Name} has adopted an insect named {AdoptedInsect.Name}.");
        }

        public void FeedInsect(string food)
        {
            if (AdoptedInsect != null)
            {
                AdoptedInsect.Eat(food);
            }
            else
            {
                Console.WriteLine($"{Name} decided to abandon the thought of taking care of an insect and walked out.");
            }
        }

        public void PlaceInsectInEnvironment(string environment)
        {
            if (AdoptedInsect != null)
            {
                AdoptedInsect.PlaceInEnvironment(environment);
            }
            else
            {
                Console.WriteLine($"Remember {Name}, You decided on not adopting an insect.");
            }
        }
        //Coded it and worked out with ChatGPT AI assitance

    }

}
