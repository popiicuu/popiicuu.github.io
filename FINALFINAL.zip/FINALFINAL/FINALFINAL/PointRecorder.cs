﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINALFINAL
{
    internal class PointRecorder
    { 
            private int points;

            public PointRecorder()
            {
                points = 0;
            }

            public void AddPoints(int value)
            {
                points += value;
            }

            public int GetPoints()
            {
                return points;
            }
        

    }
}
