﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINALFINAL
{
    internal class UserDataRecorder
    {
       
            private string userName;
            private int userAge;

            public UserDataRecorder(string name, int age)
            {
                userName = name;
                userAge = age;
            }

            public string GetName()
            {
                return userName;
            }

            public int GetAge()
            {
                return userAge;
            }
        
    }
}

