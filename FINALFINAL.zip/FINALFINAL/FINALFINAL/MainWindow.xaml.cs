﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection.Metadata;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static System.Formats.Asn1.AsnWriter;
using static System.Runtime.InteropServices.JavaScript.JSType;

//All code is provided by Friendly Neighborhood Programmer on Youtube.
//This specific code is from "C#, How to make a basic game with WPF.xaml Pt1 Movement and Part 2 Collisions
//I have lost my love and passion to be creative
//The classes made were made with CHAT GPT assitance and ihave been trying to make the score counter work but it isn't for some reason. QuQ

namespace FINALFINAL
{
    public partial class MainWindow : Window
    {
        private DispatcherTimer Gametimer = new DispatcherTimer();
        private bool UpKeyPressed, DownKeyPressed, LeftKeyPressed, RightKeyPressed;
        private float SpeedX, SpeedY, Friction = 0.88f, Speed = 2;
        private int score = 0;

        public MainWindow()
        {
            InitializeComponent();
            GameScreen.Focus();

            UpdateScore();

            Gametimer.Interval = TimeSpan.FromMilliseconds(20);
            Gametimer.Tick += GameTick;
            Gametimer.Start();
        }

        private void UpdateScore()
        {
            ScoreDisplay.Text = "Score: " + score.ToString();
        }

        private void KeyboardUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.W)
            {
                UpKeyPressed = false;
            }
            if (e.Key == Key.A)
            {
                LeftKeyPressed = false;
            }
            if (e.Key == Key.D)
            {
                RightKeyPressed = false;
            }
            if (e.Key == Key.S)
            {
                DownKeyPressed = false;
            }
        }

        private void KeyboardDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.W)
            {
                UpKeyPressed = true;
            }
            if (e.Key == Key.A)
            {
                LeftKeyPressed = true;
            }
            if (e.Key == Key.D)
            {
                RightKeyPressed = true;
            }
            if (e.Key == Key.S)
            {
                DownKeyPressed = true;
            }
        }

        private void GameTick(object sender, EventArgs e)
        {
            // Update score display
            UpdateScore();

            // Movement logic
            if (UpKeyPressed)
            {
                SpeedY += Speed;
            }
            if (RightKeyPressed)
            {
                SpeedX += Speed;
            }
            if (LeftKeyPressed)
            {
                SpeedX -= Speed;
            }
            if (DownKeyPressed)
            {
                SpeedY -= Speed;
            }

            SpeedX = SpeedX * Friction;
            SpeedY = SpeedY * Friction;

            Canvas.SetLeft(Player, Canvas.GetLeft(Player) + SpeedX);
            Collide("x");
            Canvas.SetTop(Player, Canvas.GetTop(Player) - SpeedY);
            Collide("y");
        }

        private void Collide(string Dir)
        {
            foreach (var x in GameScreen.Children.OfType<Rectangle>())
            {
                if ((string)x.Tag == "Collide")
                {
                    Rect PlayerHB = new Rect(Canvas.GetLeft(Player), Canvas.GetTop(Player), Player.Width, Player.Height);
                    Rect ToCollide = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (PlayerHB.IntersectsWith(ToCollide))
                    {
                        if (Dir == "x")
                        {
                            Canvas.SetLeft(Player, Canvas.GetLeft(Player) - SpeedX);
                            SpeedX = 0;
                        }
                        else
                        {
                            Canvas.SetTop(Player, Canvas.GetTop(Player) + SpeedY);
                            SpeedY = 0;
                        }

                        if (Player.Fill == Brushes.Red)
                        {
                            score++;
                        }
                    }
                }
            }
        }
    }
}
