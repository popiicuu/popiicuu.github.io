﻿// See https://aka.ms/new-console-template for more information

using System.Data.Common;
using System.Text;

namespace MothsDen
{
    namespace takeiteasydawgthisisconsolewriteonly
    {
        public class Program
        {
            static void Main()
            {
                //opening of Moth's den game(Include ASSCI art)
                Console.WriteLine("Welcome to");
                Console.WriteLine(@" __  __       _   _     _       ____             
|  \/  | ___ | |_| |__ ( )___  |  _ \  ___ _ __  
| |\/| |/ _ \| __| '_ \|// __| | | | |/ _ \ '_ \ 
| |  | | (_) | |_| | | | \__ \ | |_| |  __/ | | |
|_|  |_|\___/ \__|_| |_| |___/ |____/ \___|_| |_|");
                Console.WriteLine("You are an investigator who is trying to figure out why your local townsfolk are going missing faster with every month passes by");
                Console.WriteLine("Unfortunately, there will hardships and decisons that will never bring relief to your consious so I must ask if you are ready Will?");
                Console.ReadKey();

                Console.WriteLine("Then let us get started...");
                Console.ReadKey();



                Console.WriteLine("You wake up from a long night surrounded by papers and an empty cold mug staining the table in coffee rings");
                Console.WriteLine("As you get ready to head out, you look around and see a notebook, camera, and taser");
                Console.ReadKey();
            }
        }





        namespace pickyuppytime
        {
            class program
            {
                static void Main(String[] args)
                {
                    Console.WriteLine("Do you want to pick up the notebook? (Yes/No):");
                    String response = Console.ReadLine();
                    if (response.ToLower() == "Yes")
                    {
                        Console.WriteLine("You shoved the notebook into your pocket");
                    }
                    else if (response.ToLower() == "No")
                    {
                        Console.WriteLine("You left the notebook lying on the desk");

                    }
                    else
                    {
                        Console.WriteLine("You can't just progress without saying anything. Say Yes or No.");
                    }

                }
            }

        }



        namespace dialouge
        {
            class Program
            {
                static void Main()
                {
                    Console.WriteLine("You look around for any other things you might need to start your morning.");
                    Console.WriteLine("As you glance around, you spot an old poloroid camera");
                    Console.ReadKey();

                }
            }
        }


        namespace pickyuppytime
        {
            class Program
            {
                static void Main(String[] args)
                {
                    Console.WriteLine("Do you want to pick up the camera? (Yes/No):");
                    String response = Console.ReadLine();
                    if (response.ToLower() == "Yes")
                    {
                        Console.WriteLine("You grabbed the camera and stuffed it into your coat pocket");
                    }
                    else if (response.ToLower() == "No")
                    {
                        Console.WriteLine("You left the camera and turned away");

                    }
                    else
                    {
                        Console.WriteLine("You can't just progress without saying anything. Say Yes or No.");
                    }

                }
            }
        }

        namespace dialouge
        {
            class program
            {
                static void Main()
                {
                    Console.WriteLine("As you are about to head out the door, you alomst trip on a taser that was given to you when you first enlisted into the detective agency.");
                    Console.WriteLine("You chuckle over the fact that the town's police department budget could barely cover the expense of handing out taser rather than actual ammunition or checks ");
                    Console.ReadKey();

                }
            }
        }

        namespace pickyuppytime
        {
            class Program
            {
                static void Main(String[] args)
                {
                    Console.WriteLine("Do you want to pick up the taser? (Yes/No):");
                    String response = Console.ReadLine();
                    if (response.ToLower() == "Yes")
                    {
                        Console.WriteLine("You grabbed the taser");
                    }
                    else if (response.ToLower() == "No")
                    {
                        Console.WriteLine("You left the taser like an idiot");

                    }
                    else
                    {
                        Console.WriteLine("You can't just progress without saying anything. Say Yes or No.");
                    }
                }
            }
        }

            namespace takeiteasydawgthisisjustcconsolewrite
            {
                class Program
                {
                    static void Main(String[] args)
                    {
                        Console.WriteLine("With your Notebook,Camera, and Taser in hand, you venture out of your house and begin questioning the locals once more");
                        Console.WriteLine("As you walk around the town, you come across Abigail, a local who was orphaned");
                        Console.WriteLine("Abigail was a teenager who was orphaned due to her mother dying and her father being one of the many missing individuals");
                        Console.WriteLine("You notice that she is packing boxes and bags into an old car that she was gifted for her 16th birthday");
                        Console.ReadKey();

                    }
                }

                namespace questioningtimeeee
                {
                    //This part of coding was also provided with the help of ChatGPT so it isn't original.
                    class Program
                    {
                        static void Main(string[] args)
                        {
                            // these are dialogue options for Abigail
                            List<string> dialogueOptions = new List<string>
            {
                "Option 1: Ask about the boxes",
                "Option 2: Offer to help her pack",
                "Option 3: Say goodbye"
            };

                            // shows the dialogue options to the player
                            Console.WriteLine("Abigail: Hi Will, How have you been? ");
                            Console.WriteLine("Dialogue Options:");
                            for (int i = 0; i < dialogueOptions.Count; i++)
                            {
                                Console.WriteLine($"{i + 1}. {dialogueOptions[i]}");
                            }

                            // Player chooses an option
                            Console.Write("Enter the number of your choice: ");
                            int choice = int.Parse(Console.ReadLine());

                            // Process player's choice
                            switch (choice)
                            {
                                case 1:
                                    Console.WriteLine("Abigail: Oh well I've decided to skip town like some of the others. There isn't much left of my home or family here so I decied to movce out and dorm in a college.");
                                    break;
                                case 2:
                                    Console.WriteLine("Abigail: Nah I'll be fine since you look busy enough. Thanks for the help though.");
                                    break;
                                case 3:
                                    Console.WriteLine("Abigail: Goodbye! And get some sleep please");
                                    break;
                                default:
                                    Console.WriteLine("Abigail: ...");
                                    break;
                            }
                        }
                    }
                }



                //This list example portion of code was brought up from chat gpt because i don't know shit
                namespace ListExample
                {
                    class Program
                    {
                        static void Main(string[] args)
                        {
                            // this part creates a new list to store items
                            List<string> items = new List<string>();

                            // this adds items to the list
                            items.Add("Notebook");
                            items.Add("Camera");
                            items.Add("Taser");

                            // this helps print out the items in the list
                            foreach (var item in items)
                            {
                                Console.WriteLine(item);
                            }
                        }
                    }
                }
                namespace takeiteasydawgthisisjustconsolewrite
                {
                    class Program
                    {
                        static void Main()
                        {
                            Console.WriteLine("As you walk away from the conversation, you begin to go around and interogate the family member of missing people.");
                            Console.WriteLine("You realize that you have a wide net of people to interview and places to visit but its slimmed down to...");
                            Console.WriteLine("The woods or Francis' house");
                            Console.ReadLine();
                            Console.Read();

                        }
                    }


                }


                //This was also provided with the help of ChatGPT dude to the fact that I really couldnt work what was taught in 7th week session


                namespace LocationTravelGame
                {
                    class Program
                    {
                        static void Main(string[] args)
                        {


                            // Displays the players options
                            Console.WriteLine("1. The Woods");
                            Console.WriteLine("2. Francis' House");


                            // Get player's choice
                            int choice = GetChoice(1, 2);

                            // Determine destination based on player's choice
                            string destination = "";
                            switch (choice)
                            {
                                case 1:
                                    destination = "The Woods";
                                    //Im trying to where if i select one or other option, it has a different set of dialouge but lead to an end
                                    VisitTheWoods();
                                    break;
                                case 2:
                                    destination = "Francis' House";
                                    VisitFrancisHouse();
                                    break;

                            }

                            Console.WriteLine($"You make your way over to {destination}.");
                        }

                        static int GetChoice(int min, int max)
                        {
                            int choice;
                            bool isValidChoice;

                            do
                            {
                                Console.Write("Which do you choose?: ");
                                string input = Console.ReadLine();
                                isValidChoice = int.TryParse(input, out choice) && choice >= min && choice <= max;

                                if (!isValidChoice)
                                {
                                    Console.WriteLine($"WRONG. Please enter a number between {min} and {max}.");
                                }

                            } while (!isValidChoice);

                            return choice;
                        }
                    }
                }

                //This kind of organization log of data (the VisitTheWood()) section) and choices was generously provided to me by Gabrielle Vidal (Tutor on Friday)
                //She let me take a screenshot and recommended to me that I organize my data in a way where it can be re-refrenced without having to always retype it
                //they gave me their card deck shuffle project organization as an example
                namespace WoodsyPoodsy
                {
                    class Program
                    {
                        static void VisitTheWoods()
                        {
                            Console.WriteLine("You decide to walk to the Woods to see if there are any clues");
                            Console.WriteLine("You even unfortunely expected to see any signs of death or the bodies of those who went missing");
                            Console.WriteLine("As you hear the crunch of dead leaves and branches under your feet, you hear a faint but ghostly whisper say...");
                            Console.ReadLine();
                            
                            Console.WriteLine(@"+-+-+-+-+-+ +-+-+-+
 |L|e|a|v|e| |N|O|W|
 +-+-+-+-+-+ +-+-+-+");
                            Console.WriteLine("You turn around in a quick panic but you twist your ankle in the process");
                        Console.WriteLine("You trip and fall into a man made pit hole and hit your head");
                        Console.WriteLine("As you slowly fall unconcious, you hear more faint whispering and the call of your name");
                        Console.WriteLine("To Be Continued");

                        }

                        static void VisitFrancisHouse()
                        {
                            Console.WriteLine("You make your way to Francis' House that sits on a seaside cliff ");
                        Console.WriteLine("As you knock the door, a lean and peckish man answered the door with a soft hello and question");
                        Console.WriteLine("Francis: Why are you here Mr.Graham? ");
                        Console.WriteLine("I'm just here on offical bussiness. Just investigating if you have heard from girlfriend Reba.");
                        Console.WriteLine("Francis: Unfortunealy no. There hasn't been any contact from her to me ever since she went missing...If you'd like, you can come inside rather than...stay in the cold");
                        Console.WriteLine("Do You go inside?");
                        Console.WriteLine("1. Yes");
                        Console.WriteLine("2. No");
                        //the Int choice section was pulled from ChatGPT again ( ai for the save on my grade and sanityyyy)
                        int choice = GetChoice(1, 2);

                        if (choice == 1)
                        {
                            Console.WriteLine("You take Francis' offer and walk inside as he closes the door behind.");
                        }
                        else
                        {
                            Console.WriteLine("You thank him for the oppertunity but decline as you have to investigate The Woods still.");
                        }

                        


                        Console.WriteLine("As you feel a blunt object wack you in the back of your skull,making you lose conciousness, you hear a faint whisper say:");
                        Console.WriteLine(@" +-+-+-+ +-+-+-+-+ +-+-+-+-+-+ +-+-+-+-+
 |Y|O|U| |C|A|N|T| |T|R|U|S|T| |T|H|E|M|
 +-+-+-+ +-+-+-+-+ +-+-+-+-+-+ +-+-+-+-+");
                        Console.WriteLine("To Be Continued");


                        Console.ReadLine();
                        Console.ReadKey();
                        }
                    }
                }


            }
        }
    }
}








//illprobablyfailngl

//how can i make randomized content for clues or npcs to be relayed?

//I genuinely am falling more and more into a depressive cycle as I continue on into this class




//this portion is copied from a class recording but it is to detail the mechanics of where the player is only allow to enter the town or woods with certain items
//genuinely don't understand any of this or why it keeps in the errored red when i copy type for type
//you kinda suck at teaching a class, even the tutors don't recommend you 
/* public class Location
 {
     public string Description { get; }
     public List<Item> Items { get; }
     public ConsoleColor ConsoleColor { get; }

     public string About()
     {
         var sb = StringBuilder(this.Description);
         sb.Append("required Items\n")
             foreach (Item i in this.Items)
         {
             sb.Append($"{i.About()}\n");
         }
         return this.Description;
     }
     public Location(string description, List<Item> items, ConsoleColor color)
     {
         this.ConsoleColor = color;
         this.Description = description;
         this.Items = items;
     }

     public bool CanTravel(List<Item> userItems)
     {
         foreach (Item i in this.Items)
         {
             foreach (Item j in userItems)
             {
                 if (i.Matches(j))
                 {
                     return true;
                 }
             }
         }
         return false;
     }
 }

 public class World
 {
     public List<Location> Locations { get; }
     public string Name { get; set; }
     public Person Player { get; set; }

     public void LocationMenu() {
         foreach (Location I in this.Locations) {
             Console.WriteLine(I.About());
         }

     }


     //is this correct?= public World(string name, Person player) { }
     public void SetupPlayer()
     {
         this.Player = new Person("Will", new List<Items>());
     }
 }
}


 public class Person
{
     public List<Item> Inventory { get; }
     public string Name { get; }
     public Person(string name, List<Item> inventory)
     {
         this.Name = name;
         this.Inventory = inventory;
     }

}

public class Utility
{
 private readonly Random random;

 public Utility()
 {
     this.random = new Random();
 }

 public int GetRandomNumber(int max)
 {
     if(max <= 0)
     {
         throw new Exception("Invaid Max,Must Be Greater Than Zero");
     }
     return random.Next(0, max);
 }
}

public void SetupWorld()
{
 Location Village = new location("Village", new List<Item>)
 {

 }

}
public void Travel(int choice) {

}*




namespace dialouge
{
    public class Program
    {
        static void Main()
        {
            Console.WriteLine("As you stand there, note in hand, you can't help but wonder Will if those people have rested far better than what the town has given them");
            Console.WriteLine("The End");
            Console.ReadLine();
            Console.ReadKey();
        }
    }

}

}*/

