﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Store_Application
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Lecter and Graham's Butcher and Bait Store!");

            Store store = new Store();
            ShoppingCart cart = new ShoppingCart();

            bool shopping = true;
            while (shopping)
            {
                Console.WriteLine("\nWhat would you like to do?");
                Console.WriteLine("1. View Products");
                Console.WriteLine("2. Add Product to Cart");
                Console.WriteLine("3. View Cart");
                Console.WriteLine("4. Checkout");
                Console.WriteLine("5. Exit");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        store.DisplayProducts();
                        break;
                    case "2":
                        Console.Write("Enter the ID of the product you want to buy: ");
                        int productId = int.Parse(Console.ReadLine());
                        store.AddToCart(productId, cart);
                        break;
                    case "3":
                        cart.DisplayCart();
                        break;
                    case "4":
                        store.Checkout(cart);
                        shopping = false;
                        break;
                    case "5":
                        shopping = false;
                        break;
                    default:
                        Console.WriteLine(" We do not carry that here, please select something else!");
                        break;
                }
            }
        }
    }
}
//assitance on framework from Chat Gpt
