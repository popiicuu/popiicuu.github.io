﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Application
{
    internal class ShoppingCart
    {
        public List<Product> Items { get; set; }

        public ShoppingCart()
        {
            Items = new List<Product>();
        }

        public void AddToCart(Product product)
        {
            Items.Add(product);
        }

        public void DisplayCart()
        {
            Console.WriteLine("Your Shopping Cart:");
            foreach (var item in Items)
            {
                Console.WriteLine($"- {item.Name} (${item.Price})");
            }
        }
    }
}
//assiatnce from Chat GPT cuz I am DUmb and there isnt any youtube video that I can watch without it being for JAVA script and not C#
