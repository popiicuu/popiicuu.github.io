﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Application
{
    internal class Store
    {
        private List<Product> products;

        public Store()
        {
            // Lists the products, price, and quantity
            //displays the text of products and the abilities(adding in cart., etc..)
            products = new List<Product>
            {
                new Product { Id = 1, Name = "Pinhead Pork Belly Sugar Cane Skewers", Price = 10.99, Quantity = 5 },
                new Product { Id = 2, Name = "Heart Taetare Tarts", Price = 19.99, Quantity = 10 },
                new Product { Id = 3, Name = "Protein Scramble", Price = 5.99, Quantity = 20 },
                new Product { Id = 4, Name = "Proscuitto Roses on Watermelon", Price = 15.75, Quantity = 5 },
                new Product { Id = 5, Name = "The Wounded Man", Price = 9.99, Quantity = 0 },
                new Product { Id = 6, Name = "Lunker Lure Buzzer Bait", Price = 12.99, Quantity = 7},
                new Product { Id = 7, Name = "Lunker Lure Slug-Go Bait", Price = 12.99, Quantity = 12},
                new Product { Id = 8, Name = "Johnson Silver Minnow Bait", Price = 12.99, Quantity = 8},
                new Product { Id = 9, Name = "Abigail Spinner Bait", Price = 13.99, Quantity = 1}
            };
        }

        public void DisplayProducts()
        {
            Console.WriteLine("Available Products:");
            foreach (var product in products)
            {
                Console.WriteLine($"{product.Id}. {product.Name} - ${product.Price} ({product.Quantity} in stock)");
            }
        }

        public bool AddToCart(int productId, ShoppingCart cart)
        {
            var product = products.Find(p => p.Id == productId);
            if (product == null)
            {
                Console.WriteLine("We don't carry that product anymore unfortunately.");
                return false;
            }

            if (product.Quantity <= 0)
            {
                Console.WriteLine("Unfortunately, we are out of that product.");
                return false;
            }

            product.Quantity--;
            cart.AddToCart(product);
            Console.WriteLine("Product added to cart!");
            return true;
        }

        public void Checkout(ShoppingCart cart)
        {
            cart.DisplayCart();
            Console.WriteLine("Thank you for shopping with us and please join us for meal!");
        }
    }
}
//Got help from chat gpt for help because im really just stupid and lost and unhappy

