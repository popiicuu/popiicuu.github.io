﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Trying_the_Trivia_Game_Again
{
    internal class Trivia_Item
    {
        private string Question;
        private string Answer;

        public Trivia_Item(string triviaQuestion, string triviaAnswer) 
        { 
            Question = triviaQuestion;
            Answer = triviaAnswer;
         

        }

        public void AskQuestion()
        {
            WriteLine(Question);
            Write("What answer are you chosing?");
            string playerAnswer = ReadLine();
            WriteLine($"You answered '{playerAnswer}'!");
            WriteLine($"The answer was '{Answer}'in the end of it all.");

        }



            
    }
}
//All credit and help goes to Micheal Hadley's "Intro to C#: 5 - Trivia Game" Video
