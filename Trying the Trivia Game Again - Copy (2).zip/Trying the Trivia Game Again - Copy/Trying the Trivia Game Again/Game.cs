﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Trying_the_Trivia_Game_Again
{
    internal class Game
    {
        private string GameTitle = "Fandom Trivia Night";
        private string Description = "While this game takes years off my life and sanity, come and test your knowledge against me and your friends";
        private Player CurrentPlayer;
        private Trivia_Item HannibalTrivia;
        private Trivia_Item SupernaturalTrivia;
        private Trivia_Item DoctorWhoTrivia;
        private Trivia_Item GenshinTrivia;
        private Trivia_Item ResidentAlienTrivia;
        private Trivia_Item Hannibal2Trivia;
        private Trivia_Item Supernatural2Trivia;
        private Trivia_Item DoctorWho2Trivia;
        private Trivia_Item Genshin2Trivia;
        private Trivia_Item ResidentAlien2Trivia;


        public Game()
        {
            string hannibalQuestion = "The Cheseapeak Ripper in the show Hannibal is Hannibal. - True or False?";
            HannibalTrivia = new Trivia_Item(hannibalQuestion,"True");

            string supernaturalQuestion = "The song CARRY ON WAYARD SON is the song most associated with the Supernatural Fandom. - True or False?";
            SupernaturalTrivia = new Trivia_Item(supernaturalQuestion,"True");

            string doctorwhoQuestion = "The 12th Doctor was continuesly played by David Tenant. - True or False?";
            DoctorWhoTrivia = new Trivia_Item(doctorwhoQuestion, "False");

            string genshinQuestion = "The Main character in Genshin is only Ather, the male protaganist in hoyo advertisments. - True or False?";
            GenshinTrivia = new Trivia_Item(genshinQuestion, "False");

            string residentalienQuestion = "The comedy show Resident Alien is based off a comic book series. - True or False?";
            ResidentAlienTrivia = new Trivia_Item(residentalienQuestion, "True");

            string hannibal2question = "The show Hannibal varries in how they demonstrate the realtionship between Will Graham and Hannibal Lecter. - True or False?";
            Hannibal2Trivia = new Trivia_Item(hannibal2question, "True");

            string supernatural2Question = "In the final season of Supernatural, Dean dies because of tetanus. - True or False?";
            Supernatural2Trivia = new Trivia_Item(supernatural2Question, "True");

            string doctorwho2Question = "In the series, the cybermen appeared as the first enemy to The Doctor and his companions. - True or False?";
            DoctorWho2Trivia = new Trivia_Item(doctorwho2Question, "False");

            string genshin2Question = "The fake world that our character explores is called Teyvat. - True or False?";
            Genshin2Trivia = new Trivia_Item(genshin2Question, "True");

            string residentalien2Question = "In Resident Alien, Harry the alien is a grey alien. - True or False?";
            ResidentAlien2Trivia = new Trivia_Item(residentalien2Question, "False");

        }
        public void Play()
        {
            Title = GameTitle;
            WriteLine($"Welcome to {GameTitle}");
            WriteLine("More like the bane of my existance!");
            WriteLine(Description);

            Write("What is your name buckoo?: ");
            string playerName = ReadLine();
            CurrentPlayer = new Player(playerName);
            WriteLine($"Is it really {playerName}? Damn...anyways welcome to {GameTitle}!");
           // WriteLine($"Well since you have just started, your score is going to start at {CurrentPlayer.Score} "); ((Lets add in this feature later))

            WriteLine("__________________________________________________");
            HannibalTrivia.AskQuestion();
            WriteLine("__________________________________________________");
            SupernaturalTrivia.AskQuestion();
            WriteLine("__________________________________________________");
            DoctorWhoTrivia.AskQuestion();
            WriteLine("__________________________________________________");
            GenshinTrivia.AskQuestion();
            WriteLine("__________________________________________________");
            ResidentAlienTrivia.AskQuestion();
            WriteLine("__________________________________________________");
            Hannibal2Trivia.AskQuestion();
            WriteLine("__________________________________________________");
            Supernatural2Trivia.AskQuestion();
            WriteLine("__________________________________________________");
            DoctorWho2Trivia.AskQuestion();
            WriteLine("__________________________________________________");
            Genshin2Trivia.AskQuestion();
            WriteLine("__________________________________________________");
            ResidentAlien2Trivia.AskQuestion();
            WriteLine("__________________________________________________");

            WriteLine("Press any key to continue");

            ReadKey();
        }
    }
}
//All credit and help goes to Micheal Hadley's "Intro to C#: 5 - Trivia Game" Video
