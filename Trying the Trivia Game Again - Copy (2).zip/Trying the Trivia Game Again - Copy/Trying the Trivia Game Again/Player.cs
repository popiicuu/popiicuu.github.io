﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trying_the_Trivia_Game_Again
{
    internal class Player
    {
        public string Name;
        public int Score;

        public Player(string playerName)
        {
            Name= playerName;
            Score= 0;
        }
    }
}
//All credit and help goes to Micheal Hadley's "Intro to C#: 5 - Trivia Game" Video
