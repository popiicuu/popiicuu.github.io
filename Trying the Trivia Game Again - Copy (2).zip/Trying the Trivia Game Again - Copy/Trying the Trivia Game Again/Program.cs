﻿// See https://aka.ms/new-console-template for more information
using Trying_the_Trivia_Game_Again;

namespace TriviaGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Game  currentgame = new Game();
            currentgame.Play();
        }
    }

}
////All credit and help goes to Micheal Hadley's "Intro to C#: 5 - Trivia Game" Video
