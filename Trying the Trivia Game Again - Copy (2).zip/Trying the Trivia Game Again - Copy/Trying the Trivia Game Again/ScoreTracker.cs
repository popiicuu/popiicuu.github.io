﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trying_the_Trivia_Game_Again
{
    internal class ScoreTracker
    {
    }
}
